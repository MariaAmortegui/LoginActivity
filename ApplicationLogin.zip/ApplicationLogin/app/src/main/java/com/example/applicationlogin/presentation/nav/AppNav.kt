package com.example.applicationlogin.presentation.nav

import androidx.navigation.NamedNavArgument

sealed class AppNav(
    val route:String,
//    val arguments:List<NamedNavArgument>
){
    object LoginScreen : AppNav(route = "loginScreen/{nombre}"){
        fun crearRouteNueva(nombre:String):String{
            return "loginScreen/$nombre"
        }
    }
    object HomeScreen : AppNav(route = "homeScreen/{user}"){
        fun createRoute(user:String):String{
            return "homeScreen/$user"
        }
    }
    object RegistrationScreen : AppNav(route = "registrationScreen")
    object ForgotPassword : AppNav(route = "forgotPassword")
    object InicioScreen : AppNav(route = "inicioScreen")
}
