package com.example.applicationlogin.presentation.screens.registration

import androidx.annotation.StringRes
import androidx.compose.compiler.plugins.kotlin.ComposeErrorMessages

data class RegisterState(
    val successRegister: Boolean = false,
    val displayProgressBar: Boolean = false,
    @StringRes val errorMessages: Int? = null
)