package com.example.applicationlogin.presentation.screens.registration

import android.app.AlertDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.applicationlogin.presentation.componentes.EventDialog
import com.example.applicationlogin.presentation.componentes.RoundedButton
import com.example.applicationlogin.presentation.componentes.SocialMediaButton
import com.example.applicationlogin.presentation.componentes.TransparentTextField
import com.example.applicationlogin.presentation.nav.AppNav

@Composable
fun RegistrationScreen(
    navController: NavController,
    state: RegisterState,
    onRegister: (nombre:String,correo:String,telefono:String,clave:String,confirmclave:String)-> Unit,
    onBack: ()-> Unit,
    onDismissDialog: ()->Unit
){
    val nombre = remember{ mutableStateOf("") }
    val correo = remember{ mutableStateOf("") }
    val telefono = remember{ mutableStateOf("") }
    val clave = remember{ mutableStateOf("") }
    val confirmclave = remember{ mutableStateOf("") }
    val focusManager = LocalFocusManager.current
    var claveVisibility by remember { mutableStateOf(false) }
    var confirmclaveVisibility by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier.fillMaxWidth()
    ){
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        onBack()
                    }) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Regresar al login",
                        tint = MaterialTheme.colors.primary
                        )
                }//fin iconbutton
                Text(
                    text = "Crear una cuenta.",
                    style = MaterialTheme.typography.h6.copy(
                        color = MaterialTheme.colors.primary
                    ))
            }//fin row
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TransparentTextField(
                    textFieldValue = nombre,
                    textLabel = "Nombre: ",
                    keyboardType = KeyboardType.Text,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )//text nombre
                TransparentTextField(
                    textFieldValue = correo,
                    textLabel = "Correo: ",
                    keyboardType = KeyboardType.Email,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )//text correo
                TransparentTextField(
                    textFieldValue = telefono,
                    textLabel = "Telefono: ",
                    keyboardType = KeyboardType.Number,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )//text telefono
                TransparentTextField(
                    textFieldValue = clave,
                    textLabel = "Contraseña: ",
                    keyboardType = KeyboardType.Password,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next,
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                claveVisibility = !claveVisibility
                            }//fin onclick
                        ){
                            Icon(
                                imageVector = if(claveVisibility){
                                    Icons.Default.Visibility
                                }else{
                                    Icons.Default.VisibilityOff
                                },
                                contentDescription = "Icono del password")
                        }
                    },//fin trailingIcon
                    visualTransformation = if(claveVisibility){
                        VisualTransformation.None
                    }else{
                        PasswordVisualTransformation()
                    }//fin if
                )//text clave
                TransparentTextField(
                    textFieldValue = confirmclave,
                    textLabel = "Confirmar contraseña: ",
                    keyboardType = KeyboardType.Password,
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            onRegister(
                                nombre.value,
                                correo.value,
                                telefono.value,
                                clave.value,
                                confirmclave.value
                            )
                        }
                    ),
                    imeAction = ImeAction.Done,
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                confirmclaveVisibility = !confirmclaveVisibility
                            }//fin onclick
                        ){
                            Icon(
                                imageVector = if(confirmclaveVisibility){
                                    Icons.Default.Visibility
                                }else{
                                    Icons.Default.VisibilityOff
                                },
                                contentDescription = "Icono del password")
                        }
                    },//fin trailingIcon
                    visualTransformation = if(confirmclaveVisibility){
                        VisualTransformation.None
                    }else{
                        PasswordVisualTransformation()
                    }//fin if
                )//text confirmar clave
                Spacer(modifier = Modifier.height(16.dp))
                RoundedButton(
                    text = "Sign Up",
                    displayProgressBar = state.displayProgressBar,
                    onClick = {
                        onRegister(
                        nombre.value,
                        correo.value,
                        telefono.value,
                        clave.value,
                        confirmclave.value
                        )//fin onRegister
                        }//fin onclick
                )//fin boton sign up
                ClickableText(
                    text = buildAnnotatedString {
                        append("Ya tengo una cuenta   ")
                        withStyle(
                            style = SpanStyle(
                                color = MaterialTheme.colors.primary,
                                fontWeight = FontWeight.Bold
                            )
                        ){
                            append("Iniciar sesion")
                        }//fin withstyle
                    },
                    onClick = {
                        navController.navigate(AppNav.InicioScreen.route)
                    })
            }//fin column interior
            Spacer(modifier = Modifier.height(16.dp) )
            Column(
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(
                   modifier = Modifier.fillMaxWidth(),
                   verticalAlignment = Alignment.CenterVertically,
                   horizontalArrangement = Arrangement.Center
                        ){
                    Divider(
                        modifier = Modifier.width(24.dp),
                        thickness = 1.dp,
                        color = Color.DarkGray
                    )//fin divider 1
                    Text(
                        modifier = Modifier.width(24.dp),
                        text = " O ",
                        style = MaterialTheme.typography.h6.copy(
                            fontWeight = FontWeight.Black
                        ))//linea OR
                    Divider(
                        modifier = Modifier.width(24.dp),
                        thickness = 1.dp,
                        color = Color.DarkGray
                    )//fin divider 2
                }//fin row
                Text(
                    modifier = Modifier
                        .padding(8.dp)
                        .fillMaxWidth(),
                    text = "Login With",
                    style = MaterialTheme.typography.body1.copy(MaterialTheme.colors.primary),
                    textAlign = TextAlign.Center
                )//fin text
            }//fin column interior
            Spacer(
                modifier = Modifier.height(16.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ){
                SocialMediaButton(
                    text = "Facebook",
                    onClick = { /*TODO*/ },
                    SocialMediaColor = MaterialTheme.colors.primary
                )
                SocialMediaButton(
                    text = "Instagram",
                    onClick = { /*TODO*/ },
                    SocialMediaColor = MaterialTheme.colors.secondaryVariant
                )
                SocialMediaButton(
                    text = "Youtube",
                    onClick = { /*TODO*/ },
                    SocialMediaColor = MaterialTheme.colors.error
                )
            }//fin column botones redes sociales
        }//fin column exterior
        if (state.errorMessages != null){
            EventDialog(
                errorMessage = state.errorMessages,
                onDismiss = onDismissDialog
            )
        }//fin if
    }//fin box
}//fin fun