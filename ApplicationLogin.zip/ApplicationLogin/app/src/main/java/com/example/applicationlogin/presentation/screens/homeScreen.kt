package com.example.applicationlogin.presentation.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.applicationlogin.R
import com.example.applicationlogin.presentation.nav.AppNav

@Composable
fun HomeScreen(navController: NavController,user:String){
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Pagina Principal $user",
            style = MaterialTheme.typography.h3.copy(
                color = MaterialTheme.colors.primary,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold
            )
        )
        Spacer(modifier = Modifier.size(20.dp))
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "Imagen home",
            contentScale = ContentScale.Inside,
            modifier = Modifier.size(400.dp)
        )
        Spacer(modifier = Modifier.size(20.dp))
        Button(onClick = { navController.navigate(AppNav.InicioScreen.route) },
        modifier = Modifier
            .width(200.dp)
            .height(50.dp)) {
            Text(text = "Salir")
        }//fin button
    }//fin column
}//fin fun