package com.example.applicationlogin.presentation.screens.login

import android.provider.ContactsContract.CommonDataKinds.Email
import android.util.Patterns
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.applicationlogin.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel(){
    val state : MutableState<LoginState> = mutableStateOf(LoginState())
    fun login( email:String,contraseña:String){
        val errorMessages = if(email.isBlank() || contraseña.isBlank()){
            R.string.error_input_empty
        }else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            R.string.error_not_e_valid_email
        }else if(email != "n@n.com"|| contraseña != "a"){
            R.string.error_invalid_credentials
        }else null
        //validacion de la variable
        errorMessages?.let {
           state.value = state.value.copy(errorMessages = it)
            return
        }//fin validacion
        //carga del modelo
        viewModelScope.launch {
            state.value = state.value.copy(displayProgressBar = true)
            delay(3000)
            state.value = state.value.copy(email= email, contra = contraseña)
            state.value = state.value.copy(displayProgressBar = true)
            state.value = state.value.copy(successLogin = true)
        }//fin viewmodelscope
    }//fin fun
    //fun para resetear el mensaje de error
    fun hideErrorDialog(){
        state.value = state.value.copy(errorMessages = null)

    }//fin fun hide
}//fin class