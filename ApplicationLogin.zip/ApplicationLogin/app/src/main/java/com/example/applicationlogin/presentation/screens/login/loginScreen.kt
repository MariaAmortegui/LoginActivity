package com.example.applicationlogin.presentation.screens.login


import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.navigation.NavController
import com.example.applicationlogin.R
import com.example.applicationlogin.presentation.componentes.EventDialog
import com.example.applicationlogin.presentation.componentes.RoundedButton
import com.example.applicationlogin.presentation.componentes.TransparentTextField
import com.example.applicationlogin.presentation.nav.AppNav


@Composable
fun LoginScreen(
    navController: NavController,
    state: LoginState,
    onLogin:(email:String,contraseña:String)->Unit,
    onNavigateRegister:()->Unit,
    onNavigateForgot:()->Unit,
    onDismissDialog: ()->Unit
){
    val emailValue = rememberSaveable {mutableStateOf("")}
    val passwordValue = rememberSaveable {mutableStateOf("")}
    var passwordVisibility  by remember {mutableStateOf(false)}
    val focusManager = LocalFocusManager.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
    ){
        Image(
            painter = painterResource(id = R.drawable.imagen),
            contentDescription = "Imagen del logo",
            contentScale = ContentScale.Inside,
            modifier = Modifier.size(400.dp)
        )
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.BottomCenter
        ){
            ConstraintLayout{
                    val(surface,fab)= createRefs()
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(500.dp)
                        .constrainAs(surface) {
                            bottom.linkTo(parent.bottom)
                        },
                    color = Color.White,
                    shape = RoundedCornerShape(
                        topStartPercent = 8,
                        topEndPercent = 8
                    )
                ){
                    Column {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Bienvenido",
                                style = MaterialTheme.typography.h4.copy(
                                    fontWeight = FontWeight.Medium
                                ))
                            Text(
                                text = "Acceder a la cuenta",
                                style = MaterialTheme.typography.h5.copy(
                                    color = MaterialTheme.colors.primaryVariant,
                                    fontWeight = FontWeight.Medium
                                ))
                        }//fin Column textos
                        Column(modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ){
                            TransparentTextField(
                                textFieldValue = emailValue,
                                textLabel = "Email: ",
                                keyboardType = KeyboardType.Email,
                                keyboardActions = KeyboardActions(
                                    onNext = {
                                        focusManager.moveFocus(focusDirection = FocusDirection.Down)
                                    }
                                ),
                                imeAction = ImeAction.Next,
                            )//fin ttf 1
                            TransparentTextField(
                                textFieldValue = passwordValue,
                                textLabel = "Contraseña: ",
                                keyboardType = KeyboardType.Password,
                                keyboardActions = KeyboardActions(
                                    onNext = {
                                        focusManager.clearFocus()
                                        onLogin(emailValue.value,passwordValue.value)
                                    }),
                                imeAction = ImeAction.Done,
                                trailingIcon = {
                                    IconButton(
                                        onClick = {
                                        passwordVisibility = !passwordVisibility
                                    }//fin onclick
                                    ){
                                        Icon(
                                            imageVector = if(passwordVisibility){
                                                Icons.Default.Visibility
                                            }else{
                                                 Icons.Default.VisibilityOff
                                                 },
                                            contentDescription = "Icono del password")
                                    }
                                },//fin trailingIcon
                            visualTransformation = if(passwordVisibility){
                                VisualTransformation.None
                            }else{
                                PasswordVisualTransformation()
                            }//fin if
                            )//fin transparent ttf 2
                            ClickableText(
                                text = buildAnnotatedString {
                                    append("                                                                  ")
                                    withStyle(
                                        style = SpanStyle(
                                            color = MaterialTheme.colors.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    ){
                                        append("Recordar contraseña")
                                    }//fin del withStyle
                                }//fin texto
                            ){
                                onNavigateForgot()
                            }//fin text contraseña
                        }//fin Column botones
                        Spacer(modifier = Modifier.size(20.dp))
                        Column (
                            modifier =Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ){
                             RoundedButton(
                                 text = "Login",
                                 displayProgressBar = state.displayProgressBar,
                                 onClick = {
                                     onLogin(emailValue.value, passwordValue.value)

                                 }//fin onclick
                             )//fin del button
                            ClickableText(
                                text = buildAnnotatedString {
                                    append("¿No tiene una cuenta activa?   ")
                                    withStyle(
                                        style = SpanStyle(
                                            color = MaterialTheme.colors.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    ){
                                    append("Sign up")
                                    }//fin del withStyle
                                }//fin texto
                            ){
                                onNavigateRegister()
                            }//fin ct
                        }//fin Column botones adicionales
                    }//fin Column exterior
                }//fin surface
                FloatingActionButton(
                    modifier = Modifier
                        .size(72.dp)
                        .constrainAs(fab) {
                            top.linkTo(surface.top, margin = (-36).dp)
                            end.linkTo(surface.end, margin = 36.dp)
                        },
                    backgroundColor = MaterialTheme.colors.primary,
                    onClick = {
                        onLogin(emailValue.value,passwordValue.value)
                    }
                ) {
                    Icon(
                        modifier = Modifier.size(72.dp),
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Boton de avanzar",
                        tint = Color.White
                    )//fin icono
                }//fin FloatingActionButton
            }//fin del constraint
        }//fin box interior
        if (state.errorMessages != null){
            EventDialog(
                errorMessage = state.errorMessages,
                onDismiss = onDismissDialog
            )
        }//fin if
    }//fin box exterior
}//fin fun login