package com.example.applicationlogin.presentation.screens.registration

import android.util.Patterns
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.applicationlogin.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RegisterViewModel : ViewModel() {
    val state : MutableState<RegisterState> = mutableStateOf(RegisterState())
    fun register(
        nombre:String,
        correo:String,
        telefono:String,
        clave:String,
        confirmclave:String
    ){
        val errorMessages = if(nombre.isBlank() || correo.isBlank()  || telefono.isBlank()
            || clave.isBlank() || confirmclave.isBlank()){
            R.string.error_input_empty
        }else if(!Patterns.PHONE.matcher(telefono).matches()){
            R.string.error_not_e_valid_phone_numbre
        }else if(!Patterns.EMAIL_ADDRESS.matcher(correo).matches()){
            R.string.error_not_e_valid_email
        }else if(clave != confirmclave){
            R.string.error_incorrectly_repeated_password
        }else null
        //validacion de la variable
        errorMessages?.let {
            state.value = state.value.copy(errorMessages = errorMessages)
            return
        }//fin validacion
        //carga del modelo
        viewModelScope.launch {
            state.value = state.value.copy(displayProgressBar = true)
            delay(3000)
            state.value = state.value.copy(displayProgressBar = true)
        }//fin viewmodelscope
    }//fin fun
    //fun para resetear el mensaje de error
    fun hideErrorDialog(){
        state.value = state.value.copy(errorMessages = null)
    }//fin fun hide
}