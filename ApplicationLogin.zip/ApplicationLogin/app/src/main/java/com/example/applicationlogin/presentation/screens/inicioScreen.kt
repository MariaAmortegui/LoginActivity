package com.example.applicationlogin.presentation.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.applicationlogin.R
import com.example.applicationlogin.presentation.nav.AppNav

@Composable
fun InicioScreen(navController: NavController){
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "INICIO",
            style = MaterialTheme.typography.h3.copy(MaterialTheme.colors.primary),
            textAlign = TextAlign.Center )
        Spacer(modifier = Modifier.size(20.dp))
        Image(
            painter = painterResource(id = R.drawable.inicio),
            contentDescription = "Imagen Inicio",
            contentScale = ContentScale.Inside,
            modifier = Modifier.size(400.dp)
        )
        Button(onClick = {navController.navigate(AppNav.LoginScreen.route)},
            modifier = Modifier
                .width(200.dp)
                .height(50.dp)) {
            Text(text = "Iniciar sesión")
        }//fin button
        Spacer(modifier = Modifier.size(20.dp))
        Button(onClick = {navController.navigate(AppNav.RegistrationScreen.route)},
            modifier = Modifier
                .width(200.dp)
                .height(50.dp)) {
            Text(text = "Registrarse")
        }//fin button
    }//fin column
}//fin fun