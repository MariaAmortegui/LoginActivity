package com.example.applicationlogin.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)

val Teal200 = Color(0xFF03DAC5)
val BLUE500 = Color(0xFF2196f3)
val BlUE800 = Color(0xFF0277B3)
val BlUE900 = Color(0xFF0d47a1)//facebook
val BlUE950 = Color(0xFF002171)
val CYAN500 = Color(0xFF00bcd4)
val CYAN700 = Color(0xff008ba3)
val CYAN800 = Color(0xff428e92)
val CYAN900 = Color(0xFF0d47a1)
val LIGHTBLUE50 = Color(0xffe1f5fe)
val LIGHTBLUE100 = Color(0xffb3e5fc)
val BLUEGREY800 = Color(0xff263238)
val BLUEGREY900 = Color(0xff000a12)
val RED600 = Color(0xffe53935)
val RED800 = Color(0xffba000d)//youtube
//Social media
val PURPLE700 = Color(0xFFBB86FC)//instagram
val YELLOW = Color(0xFFFAEB0D)//Google


