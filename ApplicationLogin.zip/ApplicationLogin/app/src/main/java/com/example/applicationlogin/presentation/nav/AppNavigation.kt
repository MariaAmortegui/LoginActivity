package com.example.applicationlogin.presentation.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.applicationlogin.presentation.screens.ForgotPassword
import com.example.applicationlogin.presentation.screens.HomeScreen
import com.example.applicationlogin.presentation.screens.InicioScreen
import com.example.applicationlogin.presentation.screens.login.LoginScreen
import com.example.applicationlogin.presentation.screens.login.LoginViewModel
import com.example.applicationlogin.presentation.screens.registration.RegisterViewModel
import com.example.applicationlogin.presentation.screens.registration.RegistrationScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AppNav.InicioScreen.route
    ) {
        val viewModel = LoginViewModel()
        composable(route = AppNav.LoginScreen.route) {
            if(viewModel.state.value.successLogin){
                LaunchedEffect(key1 = Unit){
                    navController.navigate(AppNav.HomeScreen.createRoute(viewModel.state.value.email))
                    ///modificamos el historial de navegacion para no poder regresar
                    {
                        popUpTo(AppNav.LoginScreen.route){
                            inclusive = true
                        }//fin popup
                    }//fin modificacion
                }//fin launcheffect
            }else {
                LoginScreen(
                    navController,
                    state = viewModel.state.value,
                    onLogin = viewModel::login,
                    onNavigateRegister = { navController.navigate(AppNav.RegistrationScreen.route) },
                    onNavigateForgot = { navController.navigate(AppNav.ForgotPassword.route)},
                    onDismissDialog = viewModel::hideErrorDialog
                )
            }//fin if
        }//fin composable login
        val viewModel2 = RegisterViewModel()
        composable(route = AppNav.RegistrationScreen.route) {
            RegistrationScreen(
                navController,
                state = viewModel2.state.value,
                onRegister = viewModel2::register,
                onBack = { navController.popBackStack() },
                onDismissDialog = viewModel2::hideErrorDialog
            )//pantalla register
        }//fin composable register
        composable(route = AppNav.HomeScreen.route,
            arguments = listOf(
                navArgument("user"){type = NavType.StringType})
        ) {
            HomeScreen(navController = navController, user = it.arguments?.getString("user")?:"")
        }
        composable(route = AppNav.ForgotPassword.route ) { ForgotPassword(navController) }
        composable(route = AppNav.InicioScreen.route){ InicioScreen(navController)}

    }//fin graphbuilder
}//fin fun